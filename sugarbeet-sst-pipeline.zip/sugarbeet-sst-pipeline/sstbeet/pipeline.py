"""End-to-end pipeline: ortho -> veg mask -> rows -> weed map -> prescription -> accuracy."""
import json
import os
import numpy as np
import rasterio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from . import detect, prescription, accuracy


def _save_raster(path, arr, like, dtype):
    with rasterio.open(like) as d:
        prof = d.profile
    prof.update(count=1, dtype=dtype, compress="deflate")
    with rasterio.open(path, "w", **prof) as o:
        o.write(arr.astype(dtype), 1)


def run(ortho, labels=None, out="outputs", cell_m=5.0, thresholds=(0.01, 0.05),
        train_frac=0.35, seed=0):
    os.makedirs(out, exist_ok=True)
    img, tr, crs, gsd = detect.read_rgb(ortho)
    veg, e = detect.vegetation_mask(img)
    ang, sp, ph = detect.estimate_rows(veg, gsd)
    rowd = detect.row_distance(veg.shape, ang, sp, ph)
    F = detect.features(img, e, rowd, veg, gsd)
    res = dict(gsd_m=gsd, row_angle_deg=float(ang), row_spacing_m=float(sp * gsd),
               veg_cover_pct=float(100 * veg.mean()))

    base = detect.clean(detect.rule_baseline(veg, rowd, gsd), gsd)
    truth = None
    if labels:
        with rasterio.open(labels) as d:
            truth = d.read(1).astype(bool)
        W = veg.shape[1]
        train_mask = np.zeros(veg.shape, bool)
        train_mask[:, : int(W * train_frac)] = True  # spatial hold-out, not random pixels
        clf = detect.train_rf(F, veg, truth, train_mask, seed=seed)
        prob = detect.predict_weed_prob(clf, F, veg)
        weed = detect.clean(prob > 0.5, gsd)
        test = ~train_mask
        res["pixel_metrics_test_RF"] = accuracy.binary_metrics(weed, truth, test)
        res["pixel_metrics_test_rule_baseline"] = accuracy.binary_metrics(base, truth, test)
        res["feature_importance"] = dict(zip(detect.FEATURE_NAMES,
                                             map(float, clf.feature_importances_)))
        _save_raster(f"{out}/weed_probability.tif", prob, ortho, "float32")
    else:
        weed = base
        res["note"] = "No labels given: rule-based inter-row baseline only, no accuracy assessment."
    _save_raster(f"{out}/weed_mask.tif", weed, ortho, "uint8")

    cover, cp = prescription.weed_cover_grid(weed, tr, gsd, cell_m)
    gdf, zone = prescription.prescription(cover, cp, tr, gsd, crs, thresholds)
    gdf.to_file(f"{out}/prescription_map.geojson", driver="GeoJSON")
    gdf.to_file(f"{out}/prescription_map.shp")
    res["savings"] = prescription.savings(zone, cp, gsd)
    if truth is not None:
        tc, _ = prescription.weed_cover_grid(truth, tr, gsd, cell_m)
        res["zone_decision_metrics"] = accuracy.zone_decision_metrics(cover, tc, thresholds[0])
        res["weed_cover_grid_r"] = float(np.corrcoef(cover.ravel(), tc.ravel())[0, 1])
    with open(f"{out}/metrics.json", "w") as f:
        json.dump(res, f, indent=2)
    _figure(img, veg, weed, truth, zone, cp, gsd, res, f"{out}/summary.png")
    return res


def _figure(img, veg, weed, truth, zone, cp, gsd, res, path):
    from matplotlib.colors import ListedColormap
    ext = [0, img.shape[1] * gsd, img.shape[0] * gsd, 0]
    fig, ax = plt.subplots(1, 4, figsize=(20, 4.6))
    ax[0].imshow(img.astype(np.uint8), extent=ext); ax[0].set_title("Drone orthomosaic (RGB)")
    ov = np.zeros((*weed.shape, 4)); ov[weed] = [1, 0.1, 0.1, 0.9]
    ax[1].imshow(img.astype(np.uint8), extent=ext); ax[1].imshow(ov, extent=ext)
    ax[1].set_title("Detected weeds (red)")
    if truth is not None:
        ov2 = np.zeros((*truth.shape, 4)); ov2[truth] = [0.1, 0.3, 1, 0.9]
        ax[2].imshow(img.astype(np.uint8), extent=ext); ax[2].imshow(ov2, extent=ext)
        ax[2].set_title("Reference weeds (blue)")
    else:
        ax[2].axis("off")
    cm = ListedColormap(["#e8e8e8", "#f4c542", "#d7301f"])
    cs = cp * gsd
    ax[3].imshow(zone, cmap=cm, vmin=0, vmax=2, extent=[0, zone.shape[1] * cs, zone.shape[0] * cs, 0])
    s = res["savings"]
    ax[3].set_title(f"Tillage prescription (grey = skip)\ntreat {s['treated_pct']}% of field")
    for a in ax:
        a.set_xlabel("m")
    plt.tight_layout(); plt.savefig(path, dpi=110); plt.close()
