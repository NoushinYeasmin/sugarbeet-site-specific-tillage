"""Pixel-level and zone-level accuracy assessment."""
import numpy as np


def binary_metrics(pred, truth, region=None):
    if region is not None:
        pred, truth = pred[region], truth[region]
    p, t = pred.astype(bool).ravel(), truth.astype(bool).ravel()
    tp, fp = int((p & t).sum()), int((p & ~t).sum())
    fn, tn = int((~p & t).sum()), int((~p & ~t).sum())
    n = tp + fp + fn + tn
    oa = (tp + tn) / n
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / n ** 2
    d = lambda a, b: a / b if b else float("nan")
    prec, rec = d(tp, tp + fp), d(tp, tp + fn)
    return dict(TP=tp, FP=fp, FN=fn, TN=tn, overall_accuracy=oa,
                kappa=d(oa - pe, 1 - pe), precision=prec, recall=rec,
                f1=d(2 * prec * rec, prec + rec), iou=d(tp, tp + fp + fn))


def zone_decision_metrics(pred_cover, true_cover, thr):
    """Did we treat the cells that truly need treatment? (cover > thr)"""
    return binary_metrics(pred_cover > thr, true_cover > thr)
