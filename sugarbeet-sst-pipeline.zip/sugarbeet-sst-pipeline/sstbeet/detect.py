"""Vegetation segmentation, crop-row geometry, and weed classification."""
import warnings
import numpy as np
import rasterio
warnings.filterwarnings("ignore", category=FutureWarning, module="skimage")
from scipy.ndimage import gaussian_filter, distance_transform_edt
from skimage.filters import threshold_otsu
from skimage.morphology import remove_small_objects
from skimage.color import rgb2hsv
from sklearn.ensemble import RandomForestClassifier


def read_rgb(path):
    with rasterio.open(path) as d:
        img = d.read([1, 2, 3]).transpose(1, 2, 0).astype(np.float32)
        return img, d.transform, d.crs, d.res[0]


def exg(img):
    s = img.sum(-1) + 1e-6
    r, g, b = (img[..., i] / s for i in range(3))
    return 2 * g - r - b


def vegetation_mask(img, min_size=8):
    e = exg(img)
    m = e > threshold_otsu(e)
    return remove_small_objects(m, min_size), e


def estimate_rows(veg, gsd, angle_range=(-30, 30), step=0.5, max_pts=300000, seed=0):
    """Row orientation (deg), spacing (px) and phase from the vegetation mask.
    Orientation = angle maximising variance of the across-row projection profile;
    spacing = autocorrelation peak; phase = circular mean of the profile."""
    ys, xs = np.nonzero(veg)
    rng = np.random.default_rng(seed)
    if len(ys) > max_pts:
        i = rng.choice(len(ys), max_pts, replace=False)
        ys, xs = ys[i], xs[i]
    best = (-1, 0, None)
    for a in np.arange(*angle_range, step):
        t = np.deg2rad(a)
        u = xs * np.cos(t) + ys * np.sin(t)
        h, _ = np.histogram(u, bins=np.arange(u.min(), u.max() + 1, 1.0))
        v = h.var()
        if v > best[0]:
            best = (v, a, h)
    _, ang, h = best
    h = h - h.mean()
    ac = np.correlate(h, h, "full")[len(h) - 1:]
    lo = max(int(0.3 / gsd), 3)  # rows >= 30 cm apart
    hi = min(int(1.2 / gsd), len(ac) - 1)
    spacing = lo + int(np.argmax(ac[lo:hi]))
    t = np.deg2rad(ang)
    u = xs * np.cos(t) + ys * np.sin(t)
    phase = np.angle(np.exp(2j * np.pi * u / spacing).mean()) / (2 * np.pi) * spacing
    return ang, spacing, phase


def row_distance(shape, ang, spacing, phase):
    """Distance (px) from each pixel to the nearest estimated crop-row centreline."""
    H, W = shape
    t = np.deg2rad(ang)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    u = xx * np.cos(t) + yy * np.sin(t) - phase
    d = np.abs(((u + spacing / 2) % spacing) - spacing / 2)
    return d.astype(np.float32)


def features(img, e, rowd, veg=None, gsd=0.05):
    hsv = rgb2hsv(img / 255.0)
    off = (veg & (rowd * gsd > 0.20)).astype(np.float32) if veg is not None else np.zeros_like(e)
    s = img.sum(-1) + 1e-6
    r, g, b = (img[..., i] / s for i in range(3))
    f = [r, g, b, e, 2 * g - r - b - (1.4 * r - g), hsv[..., 0], hsv[..., 1], hsv[..., 2],
         gaussian_filter(e, 2), gaussian_filter(e, 5), rowd,
         gaussian_filter(off, 4), gaussian_filter(off, 12),
         distance_transform_edt(veg) if veg is not None else np.zeros_like(e)]
    return np.stack(f, -1).astype(np.float32)


FEATURE_NAMES = ["r", "g", "b", "ExG", "ExGR", "H", "S", "V", "ExG_s2", "ExG_s5", "row_dist", "offrow_s4", "offrow_s12", "veg_thickness"]


def rule_baseline(veg, rowd, gsd, tol_m=0.20):
    """Inter-row rule: vegetation farther than tol_m from a row line = weed."""
    return veg & (rowd * gsd > tol_m)


def train_rf(F, veg, truth, train_mask, n_samples=60000, seed=0):
    idx = np.flatnonzero((veg & train_mask).ravel())
    rng = np.random.default_rng(seed)
    idx = rng.choice(idx, min(n_samples, len(idx)), replace=False)
    clf = RandomForestClassifier(n_estimators=150, max_depth=14, min_samples_leaf=5,
                                 class_weight="balanced", n_jobs=-1, random_state=seed)
    clf.fit(F.reshape(-1, F.shape[-1])[idx], truth.ravel()[idx])
    return clf


def predict_weed_prob(clf, F, veg, chunk=500000):
    prob = np.zeros(veg.shape, np.float32)
    idx = np.flatnonzero(veg.ravel())
    Ff = F.reshape(-1, F.shape[-1])
    out = np.zeros(len(idx), np.float32)
    for i in range(0, len(idx), chunk):
        out[i:i + chunk] = clf.predict_proba(Ff[idx[i:i + chunk]])[:, 1]
    prob.ravel()[idx] = out
    return prob


def clean(mask, gsd, min_area_m2=0.0004):
    return remove_small_objects(mask, max(int(min_area_m2 / gsd ** 2), 2))
