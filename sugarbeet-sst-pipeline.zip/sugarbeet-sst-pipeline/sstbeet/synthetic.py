"""Synthetic sugar-beet field generator (for demo / unit tests ONLY).

Produces an RGB orthomosaic GeoTIFF and a ground-truth weed mask GeoTIFF in a
UTM CRS (default EPSG:32614, North Dakota). Crop and weed colours deliberately
overlap, so row geometry carries real signal, as in real imagery.
Results on this data are NOT evidence of field performance.
"""
import numpy as np
import rasterio
from rasterio.transform import from_origin
from scipy.ndimage import gaussian_filter


def _stamp(lab, cy, cx, r, val):
    h, w = lab.shape
    y0, y1 = max(int(cy - r), 0), min(int(cy + r) + 1, h)
    x0, x1 = max(int(cx - r), 0), min(int(cx + r) + 1, w)
    if y0 >= y1 or x0 >= x1:
        return
    yy, xx = np.ogrid[y0:y1, x0:x1]
    m = (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r
    lab[y0:y1, x0:x1][m] = val


def make_field(out_dir, width_m=100, height_m=80, gsd=0.05, row_spacing=0.56,
               plant_spacing=0.20, row_angle_deg=7.0, n_hotspots=6, seed=0,
               crs="EPSG:32614", origin=(650000.0, 5160000.0)):
    rng = np.random.default_rng(seed)
    W, H = int(width_m / gsd), int(height_m / gsd)
    lab = np.zeros((H, W), np.uint8)  # 0 soil, 1 crop, 2 weed
    th = np.deg2rad(row_angle_deg)
    c, s = np.cos(th), np.sin(th)
    diag = int(np.hypot(W, H))
    sp_px, pl_px = row_spacing / gsd, plant_spacing / gsd

    # crop plants on rotated row grid (with small skips / jitter)
    for k in range(-diag // int(sp_px), diag // int(sp_px)):
        u = k * sp_px + W / 2
        for v in np.arange(-diag / 2, diag / 2, pl_px):
            if rng.random() < 0.06:  # missing plant
                continue
            jx, jy = rng.normal(0, 0.6, 2)
            x = W / 2 + (u - W / 2) * c - v * s + jx
            y = H / 2 + (u - W / 2) * s + v * c + jy
            _stamp(lab, y, x, rng.uniform(2.5, 4.0), 1)

    # weed hotspots: clustered, mix of inter-row and in-row
    hot = np.c_[rng.uniform(0.1 * W, 0.9 * W, n_hotspots),
                rng.uniform(0.1 * H, 0.9 * H, n_hotspots),
                rng.uniform(4 / gsd, 12 / gsd, n_hotspots)]
    for hx, hy, hr in hot:
        n = int(rng.uniform(150, 450))
        pts = rng.normal([hx, hy], hr / 1.6, (n, 2))
        for x, y in pts:
            _stamp(lab, y, x, rng.uniform(1.5, 4.5), 2)
    bg = rng.uniform(0, 1)  # sparse background weeds everywhere
    for _ in range(int(250 + 100 * bg)):
        _stamp(lab, rng.uniform(0, H), rng.uniform(0, W), rng.uniform(1.2, 3), 2)

    # render RGB
    noise = gaussian_filter(rng.normal(0, 1, (H, W)), 6)
    light = 1 + 0.12 * noise / noise.std()
    soil = np.stack([120, 96, 76], -1).astype(float) + rng.normal(0, 7, (H, W, 3))
    crop = np.array([70, 125, 55], float) + rng.normal(0, 14, (H, W, 3))
    weed = np.array([88, 140, 58], float) + rng.normal(0, 16, (H, W, 3))
    img = soil.copy()
    img[lab == 1] = crop[lab == 1]
    img[lab == 2] = weed[lab == 2]
    img = np.clip(img * light[..., None], 0, 255).astype(np.uint8)

    tr = from_origin(origin[0], origin[1], gsd, gsd)
    prof = dict(driver="GTiff", height=H, width=W, crs=crs, transform=tr,
                compress="deflate")
    rgb_p, gt_p = f"{out_dir}/ortho_rgb.tif", f"{out_dir}/ground_truth_weed.tif"
    with rasterio.open(rgb_p, "w", count=3, dtype="uint8", **prof) as d:
        d.write(img.transpose(2, 0, 1))
    with rasterio.open(gt_p, "w", count=1, dtype="uint8", **prof) as d:
        d.write((lab == 2).astype(np.uint8), 1)
    return rgb_p, gt_p
