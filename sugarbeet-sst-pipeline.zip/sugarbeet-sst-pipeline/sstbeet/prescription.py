"""Weed-density grid -> management zones -> GIS prescription map (GeoJSON/Shapefile)."""
import numpy as np
import geopandas as gpd
from shapely.geometry import box
from rasterio.transform import array_bounds


def weed_cover_grid(weed, transform, gsd, cell_m=5.0):
    """Weed cover fraction per square cell. Returns (cover[ny,nx], cell_px)."""
    cp = max(int(round(cell_m / gsd)), 1)
    H, W = weed.shape
    ny, nx = H // cp, W // cp
    w = weed[:ny * cp, :nx * cp].reshape(ny, cp, nx, cp)
    return w.mean(axis=(1, 3)), cp


def prescription(cover, cp, transform, gsd, crs, thresholds=(0.01, 0.05),
                 labels=("none", "low", "high")):
    """Zone class per cell: 0 = no tillage, 1 = low-intensity, 2 = high-intensity.
    thresholds are weed-cover fractions (defaults: 1% and 5% of cell area)."""
    zone = np.digitize(cover, thresholds)
    ny, nx = cover.shape
    cs = cp * gsd
    x0, y0 = transform.c, transform.f
    geoms, rows = [], []
    for i in range(ny):
        for j in range(nx):
            geoms.append(box(x0 + j * cs, y0 - (i + 1) * cs, x0 + (j + 1) * cs, y0 - i * cs))
            rows.append((i, j, float(cover[i, j]), int(zone[i, j]), labels[zone[i, j]]))
    gdf = gpd.GeoDataFrame(rows, columns=["row", "col", "weed_cover", "zone", "action"],
                           geometry=geoms, crs=crs)
    return gdf, zone


def savings(zone, cp, gsd):
    """Area treated under site-specific vs. whole-field cultivation."""
    cell_ha = (cp * gsd) ** 2 / 1e4
    total = zone.size * cell_ha
    treated = (zone > 0).sum() * cell_ha
    return dict(field_ha=round(total, 3), treated_ha=round(treated, 3),
                treated_pct=round(100 * treated / total, 1),
                area_saved_pct=round(100 * (1 - treated / total), 1))
