"""sstbeet: drone imagery -> weed map -> site-specific tillage prescription (sugar beet)."""
__version__ = "0.1.0"
