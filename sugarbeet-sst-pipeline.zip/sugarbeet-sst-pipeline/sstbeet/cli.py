import argparse
import json
import os
from . import synthetic, pipeline


def main():
    ap = argparse.ArgumentParser(prog="sstbeet")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("demo", help="generate a SYNTHETIC field and run the full pipeline")
    d.add_argument("--out", default="outputs")
    d.add_argument("--seed", type=int, default=0)
    r = sub.add_parser("run", help="run on a real orthomosaic GeoTIFF")
    r.add_argument("--ortho", required=True, help="RGB GeoTIFF in a projected (metre) CRS")
    r.add_argument("--labels", help="optional weed mask GeoTIFF (1 = weed) for training + accuracy")
    r.add_argument("--out", default="outputs")
    r.add_argument("--cell", type=float, default=5.0, help="prescription grid cell size (m)")
    r.add_argument("--thr", type=float, nargs=2, default=[0.01, 0.05],
                   help="weed-cover thresholds for low/high zones")
    a = ap.parse_args()
    if a.cmd == "demo":
        os.makedirs(a.out, exist_ok=True)
        rgb, gt = synthetic.make_field(a.out, seed=a.seed)
        res = pipeline.run(rgb, gt, a.out, seed=a.seed)
    else:
        res = pipeline.run(a.ortho, a.labels, a.out, a.cell, tuple(a.thr))
    res.pop("feature_importance", None)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
