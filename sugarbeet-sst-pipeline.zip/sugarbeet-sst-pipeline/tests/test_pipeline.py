import numpy as np
from sstbeet import synthetic, detect, pipeline, accuracy


def test_row_estimation(tmp_path):
    rgb, _ = synthetic.make_field(tmp_path, width_m=40, height_m=30, row_angle_deg=7.0)
    img, tr, crs, gsd = detect.read_rgb(rgb)
    veg, _ = detect.vegetation_mask(img)
    ang, sp, _ = detect.estimate_rows(veg, gsd)
    assert abs(ang - 7.0) < 1.5
    assert abs(sp * gsd - 0.56) < 0.05


def test_metrics_perfect():
    a = np.array([[1, 0], [0, 1]], bool)
    m = accuracy.binary_metrics(a, a)
    assert m["f1"] == 1 and m["kappa"] == 1


def test_end_to_end(tmp_path):
    rgb, gt = synthetic.make_field(tmp_path, width_m=60, height_m=40)
    res = pipeline.run(rgb, gt, str(tmp_path / "o"))
    assert res["pixel_metrics_test_RF"]["f1"] > res["pixel_metrics_test_rule_baseline"]["f1"]
    assert (tmp_path / "o" / "prescription_map.geojson").exists()
