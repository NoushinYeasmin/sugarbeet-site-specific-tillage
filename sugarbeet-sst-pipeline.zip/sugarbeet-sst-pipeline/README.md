# sugarbeet-sst-pipeline

Drone imagery → weed map → GIS prescription map for **site-specific tillage (SST)** in sugar beet.
Mirrors the workflow: UAV ortho → ML weed detection → georeferenced weed density → prescription → accuracy assessment.

## Pipeline
1. **Vegetation segmentation**: ExG + Otsu threshold
2. **Crop-row geometry**: row angle, spacing and phase estimated from the vegetation mask (no manual input)
3. **Weed classification**: Random Forest on colour, ExG/ExGR, texture, row-distance and off-row context features; **spatial hold-out** (train left 35% of field, test on the rest). An inter-row rule baseline is reported alongside.
4. **Prescription map**: weed cover per 5 m cell → zones (skip / low / high) → GeoJSON + Shapefile (UTM CRS preserved)
5. **Accuracy assessment**: pixel-level (precision, recall, F1, IoU, kappa) and zone-level treat/skip decisions, plus % area saved vs. whole-field cultivation

## Run
```bash
pip install -r requirements.txt
python -m sstbeet.cli demo                       # synthetic field, full pipeline -> outputs/
python -m sstbeet.cli run --ortho field.tif --labels weed_mask.tif --out results/   # real data
pytest
```
`--labels` is optional; without it only the rule baseline runs and no accuracy is reported.

## Outputs (`outputs/`)
`summary.png`, `metrics.json`, `weed_mask.tif`, `weed_probability.tif`, `prescription_map.geojson/.shp`

## IMPORTANT: demo data is synthetic
The demo field is simulated (crop rows, clustered weeds, overlapping colours). Numbers from it show the
code works; they are **not** evidence of field performance. Next step: run on a real labelled UAV dataset
and report those numbers.

## Roadmap
- Replace RF with a CNN/U-Net segmentation and compare
- Multispectral indices (NDVI, NDRE) when available
- Export prescription in controller-ready formats
- Cercospora leaf spot monitoring via vegetation-index time series
